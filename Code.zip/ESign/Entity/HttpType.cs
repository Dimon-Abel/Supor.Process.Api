﻿namespace ESign.Entity
{
    class HttpType
    {
        public static string POST { get; private set; } = "POST";
        public static string GET { get; private set; } = "GET";
        public static string DELETE { get; private set; } = "DELETE";
        public static string PUT { get; private set; } = "PUT";
    }
}
