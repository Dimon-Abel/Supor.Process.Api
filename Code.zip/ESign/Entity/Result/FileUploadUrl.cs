﻿namespace ESign.Entity.Result
{
    public class FileUploadUrl
    {
        public string fileId {  get; set; }

        public string fileUploadUrl {  get; set; }
    }
}
