﻿namespace ESign.Entity.Result
{
    public class SignUrl
    {
        public string shortUrl {  get; set; }
        public string url { get; set; }
    }
}
