﻿namespace ESign.Entity.Result
{
    public class CreateByFile
    {
        public string signFlowId {  get; set; }
    }
}
